package com.JWTToken.demo.service;

import com.JWTToken.demo.entity.User;

public interface UserService {

	public User saveUser(User user);
	public User getemail(User user);
}
