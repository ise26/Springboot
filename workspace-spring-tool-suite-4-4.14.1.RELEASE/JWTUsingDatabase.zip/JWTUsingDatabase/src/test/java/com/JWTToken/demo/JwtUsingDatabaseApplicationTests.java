package com.JWTToken.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JwtUsingDatabaseApplicationTests {

	@Test
	void contextLoads() {
	}

}
